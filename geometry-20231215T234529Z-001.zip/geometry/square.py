
def area(a):
    return a * a


def perimeter(a):
    return 4 * a
